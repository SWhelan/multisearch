#MultiSearch

##Installation and Usage
1. Open chrome and navigate to: [chrome://extensions/](chrome://extensions/)
2. Drag and drop multisearch.crx onto the extensions page to install it
3. Perform a google search I highly recomend: [this search](https://www.google.com/search?q=cats)
4. Click the "M" in the Chrome Browser